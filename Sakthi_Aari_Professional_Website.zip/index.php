<?php
session_start();
$dataFile = __DIR__ . '/data/site.json';
if (!file_exists($dataFile)) { header('Location: admin/setup.php'); exit; }
$data = json_decode(file_get_contents($dataFile), true);
$gallery = $data['gallery'] ?? [];
?>
<!doctype html><html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?=htmlspecialchars($data['business_name'])?> | Aari Embroidery & Painting</title>
<meta name="description" content="<?=htmlspecialchars($data['tagline'])?>">
<link rel="stylesheet" href="assets/style.css"></head><body>
<header class="site-header"><div class="container nav">
<a class="brand" href="#home"><img src="assets/logo.png" alt="Sakthi Aari Embroidery & Painting"></a>
<button class="menu-btn" onclick="document.querySelector('.nav-links').classList.toggle('open')">☰</button>
<nav class="nav-links"><a href="#home">Home</a><a href="#services">Services</a><a href="#gallery">Gallery</a><a href="#about">About</a><a href="#contact">Contact</a></nav>
</div></header>
<main>
<section id="home" class="hero"><div class="hero-bg"></div><div class="container hero-grid">
<div class="hero-copy"><span class="eyebrow">SAREE • DRESS • BLOUSE • EMBROIDERY • PAINTING</span>
<h1><?=htmlspecialchars($data['headline'])?></h1><p><?=nl2br(htmlspecialchars($data['tagline']))?></p>
<div class="hero-actions"><a class="btn btn-primary" href="#contact">Contact Us</a>
<?php if(!empty($data['whatsapp'])): ?><a class="btn btn-outline" target="_blank" href="https://wa.me/<?=preg_replace('/\D/','',$data['whatsapp'])?>">WhatsApp</a><?php endif; ?></div></div>
<div class="hero-art"><img src="assets/logo.png" alt=""></div></div></section>

<section id="services" class="section"><div class="container">
<div class="section-title"><span>WHAT WE DO</span><h2>Our Services</h2><p>Beautiful, customized work crafted with care and detail.</p></div>
<div class="cards"><?php foreach(($data['services']??[]) as $s): ?>
<article class="service-card"><div class="service-icon"><?=htmlspecialchars($s['icon'])?></div><h3><?=htmlspecialchars($s['title'])?></h3><p><?=htmlspecialchars($s['text'])?></p></article>
<?php endforeach; ?></div></div></section>

<section id="gallery" class="section section-alt"><div class="container">
<div class="section-title"><span>OUR WORK</span><h2>Gallery</h2><p>Latest designs and creations.</p></div>
<div class="gallery"><?php if(!$gallery): ?><div class="empty">Gallery photos will appear here.</div><?php endif; ?>
<?php foreach($gallery as $g): ?><figure class="gallery-item"><img src="uploads/<?=htmlspecialchars($g['file'])?>" alt="<?=htmlspecialchars($g['title'])?>" loading="lazy"><figcaption><?=htmlspecialchars($g['title'])?></figcaption></figure><?php endforeach; ?></div>
</div></section>

<section id="about" class="section"><div class="container about-grid">
<div><img class="card-image" src="assets/visiting-card.png" alt="Sakthi Aari Embroidery visiting card"></div>
<div><div class="section-title left"><span>ABOUT US</span><h2><?=htmlspecialchars($data['business_name'])?></h2></div>
<p class="lead"><?=nl2br(htmlspecialchars($data['about']))?></p><div class="quote">“We design your dream… We stitch your style…”</div></div></div></section>

<section id="contact" class="section contact-section"><div class="container">
<div class="section-title"><span>GET IN TOUCH</span><h2>Contact Us</h2></div>
<div class="contact-grid">
<div class="contact-box"><b>📞 Phone</b><a href="tel:<?=htmlspecialchars($data['phone'])?>"><?=htmlspecialchars($data['phone'])?></a></div>
<div class="contact-box"><b>📍 Address</b><p><?=nl2br(htmlspecialchars($data['address']))?></p></div>
<div class="contact-box"><b>✉ Email</b><a href="mailto:<?=htmlspecialchars($data['email'])?>"><?=htmlspecialchars($data['email'])?></a></div>
<div class="contact-box"><b>📱 Social</b><div class="socials">
<?php if($data['instagram']): ?><a target="_blank" href="<?=htmlspecialchars($data['instagram'])?>">Instagram</a><?php endif; ?>
<?php if($data['facebook']): ?><a target="_blank" href="<?=htmlspecialchars($data['facebook'])?>">Facebook</a><?php endif; ?>
</div></div></div></div></section>
</main><footer><div class="container footer-inner"><span>© <?=date('Y')?> <?=htmlspecialchars($data['business_name'])?></span><a href="admin/">Admin Login</a></div></footer>
<script src="assets/app.js"></script></body></html>